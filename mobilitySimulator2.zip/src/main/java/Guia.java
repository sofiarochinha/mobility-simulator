public class Guia{

    private int guias;

    public Guia() {
        this.guias = 20;
    }

    public int getGuias() {
        return guias;
    }

    public void setGuias(int guias) {
        this.guias = guias;
    }

}
